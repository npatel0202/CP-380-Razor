﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ContosoPets.Ui.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}